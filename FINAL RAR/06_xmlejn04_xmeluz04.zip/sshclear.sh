#!/usr/bin/sudo bash

ssh -S true ubuntu@192.168.70.128 'sudo ~/Desktop/IMS-test/clearcache.sh && exit' 
